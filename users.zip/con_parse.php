<?php
include_once("scripts/userlog.php");


$sql_p =mysql_query("SELECT * from users where id='$logOptions_id'");
while($row=mysql_fetch_array($sql_p)){

	$phone2 = $row['phone'];




if ($_POST["request"] == "acceptCon") {

	$encrypted_id = $_POST['reqID'];
	
	$sql = "SELECT * FROM con_req WHERE usera='$encrypted_id' AND userb='$phone2' LIMIT 1";
	$query = mysql_query($sql) or die ("Sorry we had a mysql error!");
	$num_rows = mysql_num_rows($query); 
	if ($num_rows < 1) {
		echo 'An error occured';
		exit();
	}
    while ($row = mysql_fetch_array($query)) { 
		$usera = $row["usera"];
		$userb = $row["userb"];
		$req_table_id = $row['id'];
    }
	$sql_con_arry_usera = mysql_query("SELECT con_array FROM users WHERE phone='$usera' LIMIT 1"); 
	$sql_con_arry_userb = mysql_query("SELECT con_array FROM users WHERE phone='$userb' LIMIT 1"); 
	while($row=mysql_fetch_array($sql_con_arry_usera)) { $con_arry_usera = $row["con_array"]; }
	while($row=mysql_fetch_array($sql_con_arry_userb)) { $con_arry_userb = $row["con_array"]; }
	if($con_arry_usera != "")
		{
		$conArryMem1 = explode(",", $con_arry_usera);
		if (in_array($userb, $conArryMem1)) { echo  'Already connected'; exit(); }
		$con_arry_usera = "$con_arry_usera,$userb";
		}else 
			{
			 $con_arry_usera = "$userb";
			  }
	if($con_arry_userb != "")
		{
		$conArryMem2 = explode(",", $con_arry_userb);
		if (in_array($usera, $conArryMem2)) { echo  'Already connected'; exit(); }
		$con_arry_userb = "$con_arry_userb,$usera";
		}else 
			{
			 $con_arry_userb = "$usera"; 
			 }
    $UpdateArrayMem1 = mysql_query("UPDATE users SET con_array='$con_arry_usera' WHERE phone='$usera'") or die (mysql_error());
    $UpdateArrayMem2 = mysql_query("UPDATE users SET con_array='$con_arry_userb' WHERE phone='$userb'") or die (mysql_error());
	$deleteThisPendingRequest = mysql_query("DELETE FROM con_req WHERE id='$req_table_id' LIMIT 1"); 
    echo 'http://'.$_SERVER['HTTP_HOST'].'/profile.php?id';
	//echo "You are now friends with this member!";
	
	exit();
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////                                                                    PART 2                                                               //////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if ($_POST["request"] == "denyCon") {
	$encrypted_id = $_POST['reqID'];
	$deleteThisPendingRequest = mysql_query("DELETE FROM con_req WHERE usera='$encrypted_id' AND userb='$phone2' LIMIT 1") 
								or die(mysql_error());
	if($deleteThisPendingRequest)
		{
		echo 'Request Denied';
		exit();
		} 
    
	exit();
}
}
?>