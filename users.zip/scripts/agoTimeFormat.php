<?php
class convertToAgo {

function convert_datetime($str) {
   		 list($date, $time) = explode(' ', $str);
    	list($year, $month, $day) = explode('-', $date);
    	list($hour, $minute, $second) = explode(':', $time);
    	$timestamp = mktime($hour, $minute, $second, $month, $day, $year);
    	return $timestamp;
}

function makeAgo($timestamp){
   			$difference_time = time() - $timestamp;
   		$time_span = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
   		$time_dur = array("60", "60", "24", "7", "4.35", "12", "10");
   		for($j = 0; $difference_time >= $time_dur[$j]; $j++)
   			$difference_time /= $time_dur[$j];
   			$difference_time = round($difference_time);
   		if($difference_time != 1) $time_span[$j].= "s";
			if($difference_time < 1)
				{
				$text = "Few $time_span[$j] ago";
				}else
   			$text = "$difference_time $time_span[$j] ago";
   			
   			return $text;
}
}
?>