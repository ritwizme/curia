<?php 
session_start();

include "../scripts/DB_connect.php";
if(isset($_POST['id'])){
	 
$id = preg_replace('#[^0-9]#i', '', $_POST['id']); 

$query="DELETE FROM blabbing WHERE id='$id'";
if(!mysql_query($query)){
echo mysql_error();
 } else { 
 		exit();

}
}

?>